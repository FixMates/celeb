FIGURE NOTES — ALL PROFILE IMAGES

This bundle contains four image slots for every performer. It includes owner-supplied photos, Creative Commons portraits with credits below, and original generic, fully clothed guides for empty slots. Guides do not depict or claim to resemble performers. The data folder for each profile is named by slug.

Creative Commons photo credits:
- Brandi Love: Toglenn, CC BY-SA 3.0 — https://commons.wikimedia.org/wiki/File:Brandi_Love_2014_(cropped).jpg
- Kendra Lust: Toglenn, CC BY-SA 3.0 — https://commons.wikimedia.org/wiki/File:Kendra_Lust_2015.jpg
- Ava Addams: Kent Madsen, CC BY-SA 2.0 — https://commons.wikimedia.org/wiki/File:Ava_Addams_(Cropped).jpg
- India Summer: Toglenn, CC BY-SA 3.0 — https://commons.wikimedia.org/wiki/File:India_Summer_2011.jpg
- Julia Ann: Baldwin Saintilus, CC BY 2.0 — https://commons.wikimedia.org/wiki/File:Julia_Ann,_2014_(cropped).jpg
- Nina Hartley: Michael Dorausch from Venice, USA, CC BY-SA 2.0 — https://commons.wikimedia.org/wiki/File:Nina_Hartley_AEE_2013.jpg
- Tanya Tate: Toglenn, CC BY-SA 3.0 — https://commons.wikimedia.org/wiki/File:Tanya_Tate,_2015_(cropped).jpg
- Phoenix Marie: Gary, CC BY-SA 2.0 — https://commons.wikimedia.org/wiki/File:Phoenix_Marie_-_2014_AVN_Adult_Entertainment_Expo_AEE_at_Hard_Rock_Hotel.jpg
- Alexis Fawx: Holly Randall Unfiltered, CC BY 3.0 — https://commons.wikimedia.org/wiki/File:Alexis_Fawx.jpg
- Cherie DeVille: Holly Randall, CC BY 3.0 — https://commons.wikimedia.org/wiki/File:211206_Cherie_Deville_The_Internet%27s_Favorite_Stepmom_(1)_13.jpg
- Bridgette B: Toglenn, CC BY-SA 3.0 — https://commons.wikimedia.org/wiki/File:Bridgette_B._2014.jpg
- Veronica Avluv: Gary, CC BY-SA 2.0 (Displayed using a 960 px Wikimedia Commons thumbnail.) — https://commons.wikimedia.org/wiki/File:D6B_1934_-_Veronica_Avluv_(12228340373).jpg
- Stormy Daniels: Alan, CC BY-SA 3.0 — https://commons.wikimedia.org/wiki/File:AN_Stormy_Daniels_1.jpg
- Ginger Lynn: Luke Ford, CC BY-SA 2.5 — https://commons.wikimedia.org/wiki/File:Ginger_Lynn,_2006.JPG
- Holly Halston: www.iafd.com, CC BY-SA 2.0 — https://commons.wikimedia.org/wiki/File:Holly_Halston_iafd.jpg
- Lisa Sparxxx: Gary, CC BY-SA 2.0 (Displayed using a 960 px Wikimedia Commons thumbnail.) — https://commons.wikimedia.org/wiki/File:09AVN58_-_Lisa_Sparxxx_(crop).jpg
- Tabitha Stevens: Luke Ford / LukeIsBack.com, CC BY-SA 2.5 — https://commons.wikimedia.org/wiki/File:Tabitha_Stevens.jpg
- Nina Mercedez: GabboT, CC BY-SA 2.0 (Displayed using a 960 px Wikimedia Commons thumbnail.) — https://commons.wikimedia.org/wiki/File:Nina_Mercedez_01_(9511904907).jpg
- Misty Stone: Baldwin Saintilus, CC BY 2.0 (Displayed using a 960 px Wikimedia Commons thumbnail.) — https://commons.wikimedia.org/wiki/File:James_Bartholet_and_Misty_Stone_at_AVN_Awards_2016_(26606380651).jpg
- Capri Cavanni: Sunshine Coast BC, CC BY 2.0 (Displayed using a 960 px Wikimedia Commons thumbnail.) — https://commons.wikimedia.org/wiki/File:Capri_Cavanni_at_AVN_Awards_2014.jpg
- Sinn Sage: Toglenn, CC BY-SA 3.0 (Displayed using a 960 px Wikimedia Commons thumbnail.) — https://commons.wikimedia.org/wiki/File:Sinn_Sage_2011.jpg
- Dani Daniels: Baldwin Saintilus, CC BY 2.0 (Displayed using a 960 px Wikimedia Commons thumbnail.) — https://commons.wikimedia.org/wiki/File:Dani_Daniels_%26_Steven_St._Croix_at_AVN_Awards_2016.jpg
- Asa Akira: Michael Dorausch, CC BY-SA 2.0 — https://commons.wikimedia.org/wiki/File:Asa_Akira,_2013_(cropped).jpg
- Teagan Presley: Luke Ford / LukeIsBack.com, CC BY-SA 2.5 — https://commons.wikimedia.org/wiki/File:Teagan_Presley,_Scott_Fayner_at_Digital_Playground_Party_2.jpg
- Eva Notty: Gary, CC BY-SA 2.0 (Displayed using a 960 px Wikimedia Commons thumbnail.) — https://commons.wikimedia.org/wiki/File:Eva_Notty_AVN_Expo_2015.jpg
- Jada Fire: Toglenn, CC BY-SA 3.0 — https://commons.wikimedia.org/wiki/File:Jada_Fire_2010.jpg

Owner-supplied photos: Angela White, Lisa Ann, and Sophie Dee. Source and reuse rights were not independently verified for owner-supplied files.
Generic measurement SVGs are original Figure Notes illustrations.
